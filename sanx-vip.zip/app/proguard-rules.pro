# Keep Shizuku UserService and AIDL interface from obfuscation/shrinking
-keep class com.raylan.sanxvip.SanxShizukuUserService { *; }
-keep interface com.raylan.sanxvip.ISanxShizukuService { *; }
-keep class com.raylan.sanxvip.ISanxShizukuService$Stub { *; }
