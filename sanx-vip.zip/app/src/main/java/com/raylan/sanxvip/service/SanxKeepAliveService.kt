package com.raylan.sanxvip.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.raylan.sanxvip.MainActivity
import com.raylan.sanxvip.R

class SanxKeepAliveService : Service() {

  companion object {
    private const val CHANNEL_ID = "sanx_vip_keep_alive"
    private const val NOTIFICATION_ID = 4096
    private const val WAKE_LOCK_TAG = "SanxVip:KeepAliveWakeLock"

    fun start(context: Context) {
      runCatching {
        val intent = Intent(context, SanxKeepAliveService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          context.startForegroundService(intent)
        } else {
          context.startService(intent)
        }
      }
    }
  }

  private var wakeLock: PowerManager.WakeLock? = null

  override fun onCreate() {
    super.onCreate()
    createNotificationChannelSafely()
    acquireWakeLockSafely()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    runCatching {
      val notification = buildNotification()
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
    acquireWakeLockSafely()
    return START_STICKY
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onDestroy() {
    releaseWakeLockSafely()
    super.onDestroy()
  }

  private fun createNotificationChannelSafely() {
    runCatching {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel =
          NotificationChannel(
              CHANNEL_ID,
              getString(R.string.notification_channel_name),
              NotificationManager.IMPORTANCE_LOW,
            )
            .apply {
              description = getString(R.string.notification_channel_desc)
              setShowBadge(false)
              setSound(null, null)
            }
        val manager = getSystemService(NotificationManager::class.java)
        manager?.createNotificationChannel(channel)
      }
    }
  }

  private fun buildNotification(): Notification {
    val pendingIntent =
      runCatching {
        val launchIntent = Intent(this, MainActivity::class.java)
        PendingIntent.getActivity(
          this,
          0,
          launchIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
      }.getOrNull()

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle(getString(R.string.notification_title))
      .setContentText(getString(R.string.notification_text))
      .setSmallIcon(R.mipmap.ic_launcher)
      .setOngoing(true)
      .setSilent(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .setCategory(NotificationCompat.CATEGORY_SERVICE)
      .apply { if (pendingIntent != null) setContentIntent(pendingIntent) }
      .build()
  }

  private fun acquireWakeLockSafely() {
    runCatching {
      if (wakeLock?.isHeld == true) return
      val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
      val lock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKE_LOCK_TAG)
      lock.setReferenceCounted(false)
      lock.acquire(6 * 60 * 60 * 1000L)
      wakeLock = lock
    }
  }

  private fun releaseWakeLockSafely() {
    runCatching {
      wakeLock?.let {
        if (it.isHeld) {
          it.release()
        }
      }
      wakeLock = null
    }
  }
}
