package com.raylan.sanxvip.data

import com.raylan.sanxvip.model.VipFeature
import com.raylan.sanxvip.model.VipTab

object VipFeaturesCatalog {

  val baselineVipCommands: List<String> =
    listOf(
      "cmd power set-fixed-performance-mode-enabled true",
      "cmd thermalservice override-status 0",
      "settings put global window_animation_scale 0.5",
      "settings put global transition_animation_scale 0.5",
      "settings put global animator_duration_scale 0.5",
    )

  val allFeatures: List<VipFeature> =
    listOf(
      // Aba 1 - Mira Avançada (18)
      VipFeature(
        id = "mira_1",
        index = 1,
        name = "Mira Rápida",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Deixa o movimento da tela mais ágil ao arrastar o dedo, ajudando você a virar e puxar a mira com mais velocidade nas trocas de curta distância.",
        systemCommands = listOf("settings put system pointer_speed 7"),
      ),
      VipFeature(
        id = "mira_2",
        index = 2,
        name = "Mira Grudenta",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Ajuda a manter a sensibilidade firme na hora da puxada, evitando que o ponto de mira escape fácil do alvo durante o spray.",
        systemCommands =
          listOf(
            "settings put secure long_press_timeout 200",
            "settings put secure tap_duration_threshold 0.0",
          ),
      ),
      VipFeature(
        id = "mira_3",
        index = 3,
        name = "Reduzir Toque Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Diminui o atraso entre o momento em que seu dedo encosta na tela e a resposta do jogo, deixando os disparos e movimentos de gel mais rápidos.",
        systemCommands =
          listOf(
            "settings put secure touch_blocking_period 0.0",
            "settings put system haptic_feedback_enabled 0",
          ),
      ),
      VipFeature(
        id = "mira_4",
        index = 4,
        name = "Reduzir Pinadeira Elite",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Suaviza oscilações bruscas de toque quando você puxa forte para cima, ajudando a controlar a arma e evitar que a mira espalhe demais.",
        systemCommands = listOf("settings put secure multi_press_timeout 180"),
      ),
      VipFeature(
        id = "mira_5",
        index = 5,
        name = "Calibração Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Ajusta a leitura de sensibilidade da tela para manter uma resposta uniforme tanto em puxadas curtas quanto longas.",
        systemCommands =
          listOf(
            "settings put system pointer_speed 6",
            "settings put global window_animation_scale 0.5",
          ),
      ),
      VipFeature(
        id = "mira_6",
        index = 6,
        name = "Reduzir Tiros Passa da Cabeça Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Ajuda a equilibrar o final da puxada para que a mira pare na altura certa do capacete sem subir direto acima do oponente.",
        systemCommands = listOf("settings put secure long_press_timeout 220"),
      ),
      VipFeature(
        id = "mira_7",
        index = 7,
        name = "Resposta Instantânea 120Hz+",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Prioriza a maior taxa de atualização suportada pela sua tela para deixar o rastro da mira muito mais fluido e com leitura imediata.",
        systemCommands =
          listOf(
            "settings put system peak_refresh_rate 120.0",
            "settings put system min_refresh_rate 120.0",
          ),
      ),
      VipFeature(
        id = "mira_8",
        index = 8,
        name = "Precisão Eterna",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Mantém o perfil de resposta tátil constante do começo ao fim da partida, evitando quedas de precisão quando o aparelho esquenta.",
        systemCommands = listOf("cmd thermalservice override-status 0"),
      ),
      VipFeature(
        id = "mira_9",
        index = 9,
        name = "Resposta Vip+",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Acelera o tempo de reação dos botões de tiro, agachar e gelo para combos mais limpos e sem engasgos no HUD.",
        systemCommands =
          listOf(
            "settings put global transition_animation_scale 0.25",
            "settings put global animator_duration_scale 0.25",
          ),
      ),
      VipFeature(
        id = "mira_10",
        index = 10,
        name = "Estabilidade de Mira Elite",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Reduz micro-travamentos no processamento do toque para que a movimentação da câmera continue lisa em trocações intensas.",
        systemCommands = listOf("cmd power set-fixed-performance-mode-enabled true"),
      ),
      VipFeature(
        id = "mira_11",
        index = 11,
        name = "Controle Fino de Recuo",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Facilita segurar rajadas médias e longas mantendo a sensibilidade mais previsível em armas AR e SMG.",
        systemCommands = listOf("settings put system pointer_speed 5"),
      ),
      VipFeature(
        id = "mira_12",
        index = 12,
        name = "Sanx Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Ativa o ajuste principal da assinatura Sanx Vip, combinando agilidade no deslize com foco de desempenho para o jogo.",
        systemCommands =
          listOf(
            "cmd power set-fixed-performance-mode-enabled true",
            "settings put system pointer_speed 7",
          ),
      ),
      VipFeature(
        id = "mira_13",
        index = 13,
        name = "Sanx Vip Código",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Aplica o conjunto avançado de calibragem de toque e prioridade visual para deixar a puxada mais responsiva.",
        systemCommands = listOf("settings put global animator_duration_scale 0.25"),
      ),
      VipFeature(
        id = "mira_14",
        index = 14,
        name = "Sanx Elite",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Modo voltado para jogadores competitivos que buscam resposta rápida de tela mesmo em celulares com muita ação na tela.",
        systemCommands =
          listOf(
            "cmd thermalservice override-status 0",
            "cmd power set-fixed-performance-mode-enabled true",
          ),
      ),
      VipFeature(
        id = "mira_15",
        index = 15,
        name = "Filtro Anti-Tremor",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Ajuda a suavizar pequenos tremores do dedo durante a mira aberta, deixando a retícula mais firme em alvos distantes.",
        systemCommands = listOf("settings put secure multi_press_timeout 200"),
      ),
      VipFeature(
        id = "mira_16",
        index = 16,
        name = "Mira Boost Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Dá um ganho extra na velocidade de resposta do eixo vertical, facilitando puxadas rápidas com armas de um tiro.",
        systemCommands = listOf("settings put system pointer_speed 7"),
      ),
      VipFeature(
        id = "mira_17",
        index = 17,
        name = "Mira Good Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Equilibra controle e velocidade para quem joga com sensibilidade alta e quer mais firmeza na cabeça.",
        systemCommands = listOf("settings put secure long_press_timeout 210"),
      ),
      VipFeature(
        id = "mira_18",
        index = 18,
        name = "Código Vip",
        tab = VipTab.MIRA_AVANCADA,
        gamerExplanation =
          "Reforça o pacote completo de fluidez de toque e resposta de tela para manter o padrão VIP ativo na partida.",
        systemCommands =
          listOf(
            "settings put global window_animation_scale 0.25",
            "settings put system haptic_feedback_enabled 0",
          ),
      ),

      // Aba 2 - Ping Avançado (17)
      VipFeature(
        id = "ping_19",
        index = 19,
        name = "Ping Ultra Baixo",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Otimiza o comportamento da rede para priorizar a troca rápida de pacotes do jogo e diminuir o atraso nos comandos.",
        systemCommands = listOf("settings put global wifi_sleep_policy 2"),
      ),
      VipFeature(
        id = "ping_20",
        index = 20,
        name = "Ping Baixo Normal",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Mantém uma conexão equilibrada e estável para partidas ranqueadas sem forçar oscilações na rede.",
        systemCommands = listOf("settings put global wifi_scan_throttle_enabled 1"),
      ),
      VipFeature(
        id = "ping_21",
        index = 21,
        name = "Ping Ultra Boost Vip",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Dá prioridade máxima de tráfego enquanto você joga, evitando que tarefas secundárias disputem sua internet.",
        systemCommands =
          listOf(
            "settings put global wifi_sleep_policy 2",
            "settings put global wifi_networks_available_notification_on 0",
          ),
      ),
      VipFeature(
        id = "ping_22",
        index = 22,
        name = "Ping FF Boost Elite",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Ajuste dedicado para manter a contagem de dano, troca de armas e gelo respondendo rápido dentro da partida.",
        systemCommands = listOf("settings put global tcp_default_init_rwnd 60"),
      ),
      VipFeature(
        id = "ping_23",
        index = 23,
        name = "Ping Vip",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Mantém a conexão desperta e constante durante toda a sessão de jogo para evitar quedas repentinas de sinal.",
        systemCommands = listOf("settings put global mobile_data_always_on 1"),
      ),
      VipFeature(
        id = "ping_24",
        index = 24,
        name = "Estabilizador de Wi-Fi 5GHz",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Reduz buscas automáticas desnecessárias em segundo plano para manter o sinal do Wi-Fi 5GHz mais firme e sem engasgos.",
        systemCommands =
          listOf(
            "settings put global wifi_scan_throttle_enabled 1",
            "settings put global wifi_sleep_policy 2",
          ),
      ),
      VipFeature(
        id = "ping_25",
        index = 25,
        name = "Estabiliza 90% do Ping",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Ajuda a segurar picos de latência causados por verificações internas do sistema, mantendo a barra de ping mais reta.",
        systemCommands = listOf("settings put global captive_portal_detection_enabled 0"),
      ),
      VipFeature(
        id = "ping_26",
        index = 26,
        name = "Resposta de Toque Elite",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Sincroniza o tempo de resposta da tela com o envio dos comandos pela rede para o tiro e o gelo saírem no tempo certo.",
        systemCommands =
          listOf(
            "settings put secure tap_duration_threshold 0.0",
            "cmd power set-fixed-performance-mode-enabled true",
          ),
      ),
      VipFeature(
        id = "ping_27",
        index = 27,
        name = "Limpeza de Redes Oculta",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Desativa varreduras silenciosas de Bluetooth e notificações de rede aberta que costumam causar travadinhas no ping.",
        systemCommands =
          listOf(
            "settings put global ble_scan_always_enabled 0",
            "settings put global wifi_networks_available_notification_on 0",
          ),
      ),
      VipFeature(
        id = "ping_28",
        index = 28,
        name = "Turbo Conexão UDP",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Favorece o envio contínuo de dados em tempo real usado pelas partidas online, deixando os movimentos mais sincronizados.",
        systemCommands = listOf("settings put global tether_offload_disabled 0"),
      ),
      VipFeature(
        id = "ping_29",
        index = 29,
        name = "Anti-Lag no Jogo",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Evita que modos de economia de energia reduzam o desempenho da rede e do processador no meio do confronto.",
        systemCommands =
          listOf(
            "cmd power set-adaptive-power-saver-enabled false",
            "settings put global adaptive_battery_management_enabled 0",
          ),
      ),
      VipFeature(
        id = "ping_30",
        index = 30,
        name = "Sincronia de Pacotes",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Melhora a cadência de envio e recebimento das informações da partida para diminuir a sensação de tiro atrasado.",
        systemCommands = listOf("settings put global tcp_default_init_rwnd 60"),
      ),
      VipFeature(
        id = "ping_31",
        index = 31,
        name = "Redutor de Jitter",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Reduz a variação brusca entre ping baixo e ping alto, evitando aqueles teletransportes chatos na tela.",
        systemCommands = listOf("settings put global wifi_scan_throttle_enabled 1"),
      ),
      VipFeature(
        id = "ping_32",
        index = 32,
        name = "Conexão Blindada",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Mantém os dados móveis prontos como apoio e evita desconexões rápidas por checagens automáticas do sistema.",
        systemCommands =
          listOf(
            "settings put global mobile_data_always_on 1",
            "settings put global captive_portal_detection_enabled 0",
          ),
      ),
      VipFeature(
        id = "ping_33",
        index = 33,
        name = "Impulso Vip",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Combina prioridade de energia com rede sempre ativa para sustentar partidas longas sem perda de ritmo.",
        systemCommands =
          listOf(
            "cmd power set-fixed-performance-mode-enabled true",
            "settings put global wifi_sleep_policy 2",
          ),
      ),
      VipFeature(
        id = "ping_34",
        index = 34,
        name = "Modo Ping Vip",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Ativa o perfil VIP de estabilidade de rede com menos interferências de segundo plano durante todo o jogo.",
        systemCommands =
          listOf(
            "settings put global ble_scan_always_enabled 0",
            "settings put global app_standby_enabled 1",
          ),
      ),
      VipFeature(
        id = "ping_35",
        index = 35,
        name = "Anti 999+ na Partida",
        tab = VipTab.PING_AVANCADO,
        gamerExplanation =
          "Protege sua conexão contra quedas súbitas para 999+ mantendo o Wi-Fi desperto, sem varreduras pesadas e sem economia de bateria limitando a rede.",
        systemCommands =
          listOf(
            "settings put global wifi_sleep_policy 2",
            "settings put global adaptive_battery_management_enabled 0",
            "cmd power set-adaptive-power-saver-enabled false",
          ),
      ),
    )

  fun featuresForTab(tab: VipTab): List<VipFeature> = allFeatures.filter { it.tab == tab }
}
