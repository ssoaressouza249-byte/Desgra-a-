package com.raylan.sanxvip.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.raylan.sanxvip.BuildConfig
import com.raylan.sanxvip.ISanxShizukuService
import com.raylan.sanxvip.SanxShizukuUserService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuConnectionState {
  DISCONNECTED,
  PERMISSION_REQUIRED,
  CONNECTING,
  CONNECTED,
}

class ShizukuManager {

  companion object {
    private const val REQUEST_CODE_SHIZUKU = 1001
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
  }

  private val _connectionState = MutableStateFlow(ShizukuConnectionState.DISCONNECTED)
  val connectionState: StateFlow<ShizukuConnectionState> = _connectionState.asStateFlow()

  private var userService: ISanxShizukuService? = null
  private var listenersRegistered = false
  private var isBound = false

  private val userServiceArgs by lazy {
    Shizuku.UserServiceArgs(
        ComponentName(BuildConfig.APPLICATION_ID, SanxShizukuUserService::class.java.name)
      )
      .daemon(false)
      .processNameSuffix("sanx_service")
      .debuggable(BuildConfig.DEBUG)
      .version(BuildConfig.VERSION_CODE)
  }

  private val serviceConnection =
    object : ServiceConnection {
      override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
        runCatching {
          if (service != null && service.pingBinder()) {
            userService = ISanxShizukuService.Stub.asInterface(service)
            isBound = true
            _connectionState.value = ShizukuConnectionState.CONNECTED
          } else {
            userService = null
            isBound = false
            refreshState()
          }
        }.onFailure {
          userService = null
          isBound = false
          refreshState()
        }
      }

      override fun onServiceDisconnected(name: ComponentName?) {
        userService = null
        isBound = false
        refreshState()
      }
    }

  private val binderReceivedListener =
    Shizuku.OnBinderReceivedListener {
      runCatching {
        refreshState()
        if (hasPermission()) {
          bindServiceSafely()
        }
      }
    }

  private val binderDeadListener =
    Shizuku.OnBinderDeadListener {
      runCatching {
        userService = null
        isBound = false
        _connectionState.value = ShizukuConnectionState.DISCONNECTED
      }
    }

  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
      runCatching {
        if (requestCode == REQUEST_CODE_SHIZUKU) {
          if (grantResult == PackageManager.PERMISSION_GRANTED) {
            bindServiceSafely()
          } else {
            _connectionState.value = ShizukuConnectionState.PERMISSION_REQUIRED
          }
        }
      }
    }

  fun initialize() {
    runCatching {
      if (!listenersRegistered) {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        listenersRegistered = true
      }
      refreshState()
      if (isBinderAlive() && hasPermission()) {
        bindServiceSafely()
      }
    }
  }

  fun refreshState() {
    runCatching {
      when {
        !isBinderAlive() -> _connectionState.value = ShizukuConnectionState.DISCONNECTED
        !hasPermission() -> _connectionState.value = ShizukuConnectionState.PERMISSION_REQUIRED
        userService != null -> _connectionState.value = ShizukuConnectionState.CONNECTED
        else -> _connectionState.value = ShizukuConnectionState.CONNECTING
      }
    }.onFailure { _connectionState.value = ShizukuConnectionState.DISCONNECTED }
  }

  fun connectOrRequestPermission(context: Context): String {
    return runCatching {
      if (!isBinderAlive()) {
        val launchIntent =
          runCatching { context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) }
            .getOrNull()
        if (launchIntent != null) {
          runCatching { context.startActivity(launchIntent) }
          "Abra e inicie o serviço no aplicativo Shizuku."
        } else {
          "Inicie o Shizuku no aparelho para conectar o modo avançado."
        }
      } else if (!hasPermission()) {
        Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        "Autorize a permissão do Shizuku para continuar."
      } else {
        bindServiceSafely()
        "Conectando ao serviço Shizuku..."
      }
    }.getOrElse { "Não foi possível verificar o Shizuku neste momento." }
  }

  suspend fun executeCommands(commands: List<String>): Boolean =
    withContext(Dispatchers.IO) {
      if (commands.isEmpty()) return@withContext false
      runCatching {
        val service = userService
        if (service != null && service.asBinder().pingBinder()) {
          val succeeded = service.executeBatch(commands.toTypedArray())
          succeeded > 0
        } else {
          if (isBinderAlive() && hasPermission()) {
            bindServiceSafely()
          }
          false
        }
      }.getOrDefault(false)
    }

  fun dispose() {
    runCatching {
      if (isBound) {
        Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
        isBound = false
      }
    }
    runCatching {
      if (listenersRegistered) {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        listenersRegistered = false
      }
    }
    userService = null
  }

  private fun bindServiceSafely() {
    runCatching {
      if (!isBinderAlive() || !hasPermission()) return
      if (userService != null && userService?.asBinder()?.pingBinder() == true) {
        _connectionState.value = ShizukuConnectionState.CONNECTED
        return
      }
      _connectionState.value = ShizukuConnectionState.CONNECTING
      Shizuku.bindUserService(userServiceArgs, serviceConnection)
    }.onFailure { refreshState() }
  }

  private fun isBinderAlive(): Boolean {
    return runCatching { Shizuku.pingBinder() }.getOrDefault(false)
  }

  private fun hasPermission(): Boolean {
    return runCatching {
      if (Shizuku.isPreV11()) {
        false
      } else {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
      }
    }.getOrDefault(false)
  }
}
