package com.raylan.sanxvip.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SanxColorScheme =
  darkColorScheme(
    primary = PureWhite,
    onPrimary = PureBlack,
    primaryContainer = CardActiveDark,
    onPrimaryContainer = PureWhite,
    secondary = PureWhite,
    onSecondary = PureBlack,
    background = PureBlack,
    onBackground = PureWhite,
    surface = CardDark,
    onSurface = PureWhite,
    surfaceVariant = CardActiveDark,
    onSurfaceVariant = MutedText,
    outline = BorderGray,
    outlineVariant = BorderGray,
    error = AlertRed,
    onError = PureWhite,
  )

@Composable
fun SanxVipTheme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = SanxColorScheme, typography = SanxTypography, content = content)
}
