package com.raylan.sanxvip.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.sanxvip.model.VipFeature
import com.raylan.sanxvip.model.VipTab
import com.raylan.sanxvip.shizuku.ShizukuConnectionState
import com.raylan.sanxvip.ui.theme.BorderGray
import com.raylan.sanxvip.ui.theme.CardActiveDark
import com.raylan.sanxvip.ui.theme.CardDark
import com.raylan.sanxvip.ui.theme.DisabledSurface
import com.raylan.sanxvip.ui.theme.MutedText
import com.raylan.sanxvip.ui.theme.PureBlack
import com.raylan.sanxvip.ui.theme.PureWhite
import kotlin.math.roundToInt

@Composable
fun SanxVipScreen(viewModel: SanxVipViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(uiState.statusMessage) {
    val message = uiState.statusMessage ?: return@LaunchedEffect
    snackbarHostState.showSnackbar(message)
    viewModel.clearStatusMessage()
  }

  Scaffold(
    containerColor = PureBlack,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = {
      SnackbarHost(hostState = snackbarHostState) { data ->
        Snackbar(
          snackbarData = data,
          containerColor = CardActiveDark,
          contentColor = PureWhite,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.border(1.dp, BorderGray, RoundedCornerShape(10.dp)),
        )
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(PureBlack)
          .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.widthIn(max = 720.dp)
            .fillMaxSize()
            .statusBarsPadding(),
      ) {
        SanxHeader(
          shizukuState = uiState.shizukuState,
          onShizukuClick = { viewModel.onShizukuButtonClick(context) },
        )

        HorizontalDivider(color = BorderGray, thickness = 1.dp)

        SanxTabsRow(
          selectedTab = uiState.selectedTab,
          onSelectTab = viewModel::selectTab,
        )

        if (!uiState.isVipInjected) {
          VipLockBanner()
        }

        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          modifier =
            Modifier.weight(1f)
              .fillMaxWidth()
              .testTag("features_grid"),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(
            items = uiState.currentTabFeatures,
            key = { it.id },
          ) { feature ->
            val isChecked = feature.id in uiState.enabledFeatureIds
            VipFeatureTile(
              feature = feature,
              isChecked = isChecked,
              isUnlocked = uiState.isVipInjected,
              onHelpClick = { viewModel.openHelp(feature) },
              onToggle = { checked -> viewModel.onFeatureSwitchChanged(feature, checked) },
            )
          }
        }

        SanxBottomPanel(
          isVipInjected = uiState.isVipInjected,
          isInjecting = uiState.isInjecting,
          progress = uiState.injectionProgress,
          stageText = uiState.injectionStageText,
          activeCount = uiState.activeCount,
          onInjectClick = { viewModel.injectVipCode(context) },
        )
      }
    }

    uiState.selectedHelpFeature?.let { helpFeature ->
      FeatureHelpModal(
        feature = helpFeature,
        onDismiss = viewModel::closeHelp,
      )
    }
  }
}

@Composable
private fun SanxHeader(
  shizukuState: ShizukuConnectionState,
  onShizukuClick: () -> Unit,
) {
  val isConnected = shizukuState == ShizukuConnectionState.CONNECTED

  Row(
    modifier =
      Modifier.fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        text = "SANX VIP",
        style = MaterialTheme.typography.headlineSmall,
        color = PureWhite,
      )
      Box(
        modifier =
          Modifier.clip(RoundedCornerShape(4.dp))
            .background(CardDark)
            .border(1.dp, BorderGray, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
      ) {
        Text(
          text = "MODO: AVANÇADO",
          style = MaterialTheme.typography.labelSmall,
          color = PureWhite,
        )
      }
    }

    Surface(
      onClick = onShizukuClick,
      shape = RoundedCornerShape(8.dp),
      color = if (isConnected) PureWhite else CardDark,
      border = BorderStroke(1.dp, if (isConnected) PureWhite else BorderGray),
      modifier =
        Modifier.minimumInteractiveComponentSize()
          .testTag("shizuku_status_button"),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = if (isConnected) Icons.Filled.CheckCircle else Icons.Outlined.Link,
          contentDescription =
            if (isConnected) "Shizuku conectado" else "Conectar Shizuku",
          tint = if (isConnected) PureBlack else PureWhite,
          modifier = Modifier.size(16.dp),
        )
        Text(
          text = if (isConnected) "SHIZUKU: CONECTADO" else "CONECTAR SHIZUKU",
          style = MaterialTheme.typography.labelMedium,
          color = if (isConnected) PureBlack else PureWhite,
        )
      }
    }
  }
}

@Composable
private fun SanxTabsRow(
  selectedTab: VipTab,
  onSelectTab: (VipTab) -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    VipTab.entries.forEach { tab ->
      val isSelected = tab == selectedTab
      Surface(
        onClick = { onSelectTab(tab) },
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) PureWhite else CardDark,
        border = BorderStroke(1.dp, if (isSelected) PureWhite else BorderGray),
        modifier =
          Modifier.weight(1f)
            .height(48.dp)
            .testTag("tab_${tab.name.lowercase()}"),
      ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
          Text(
            text = tab.title,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = if (isSelected) PureBlack else MutedText,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
          )
        }
      }
    }
  }
}

@Composable
private fun VipLockBanner() {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .padding(horizontal = 16.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(CardDark)
        .border(1.dp, BorderGray, RoundedCornerShape(8.dp))
        .padding(horizontal = 12.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Icon(
      imageVector = Icons.Filled.Lock,
      contentDescription = "Módulos bloqueados",
      tint = PureWhite,
      modifier = Modifier.size(15.dp),
    )
    Text(
      text = "Toque em INJETAR CÓDIGO VIP abaixo para liberar os switches.",
      style = MaterialTheme.typography.labelSmall,
      color = MutedText,
      maxLines = 2,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun VipFeatureTile(
  feature: VipFeature,
  isChecked: Boolean,
  isUnlocked: Boolean,
  onHelpClick: () -> Unit,
  onToggle: (Boolean) -> Unit,
) {
  val cardBackground = if (isChecked && isUnlocked) CardActiveDark else CardDark
  val borderColor = if (isChecked && isUnlocked) PureWhite else BorderGray

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = cardBackground,
    border = BorderStroke(1.dp, borderColor),
    modifier =
      Modifier.fillMaxWidth()
        .height(142.dp)
        .testTag("feature_card_${feature.index}"),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "#${feature.index.toString().padStart(2, '0')}",
          style = MaterialTheme.typography.labelSmall,
          color = if (isChecked && isUnlocked) PureWhite else MutedText,
        )

        Box(
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .clickable(onClick = onHelpClick)
              .semantics { contentDescription = "Explicação de ${feature.name}" }
              .testTag("help_button_${feature.index}"),
          contentAlignment = Alignment.CenterEnd,
        ) {
          Box(
            modifier =
              Modifier.size(26.dp)
                .clip(CircleShape)
                .background(PureBlack)
                .border(1.dp, BorderGray, CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "(?)",
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
              color = PureWhite,
            )
          }
        }
      }

      Text(
        text = feature.name,
        style = MaterialTheme.typography.titleSmall,
        color = PureWhite,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            when {
              !isUnlocked -> "BLOQUEADO"
              isChecked -> "ATIVO"
              else -> "PRONTO"
            },
          style = MaterialTheme.typography.labelSmall,
          color = if (isChecked && isUnlocked) PureWhite else MutedText,
        )

        Switch(
          checked = isChecked,
          onCheckedChange = onToggle,
          enabled = isUnlocked,
          modifier = Modifier.testTag("feature_switch_${feature.index}"),
          colors =
            SwitchDefaults.colors(
              checkedThumbColor = PureBlack,
              checkedTrackColor = PureWhite,
              checkedBorderColor = PureWhite,
              uncheckedThumbColor = MutedText,
              uncheckedTrackColor = PureBlack,
              uncheckedBorderColor = BorderGray,
              disabledCheckedThumbColor = MutedText,
              disabledCheckedTrackColor = DisabledSurface,
              disabledUncheckedThumbColor = BorderGray,
              disabledUncheckedTrackColor = PureBlack,
              disabledUncheckedBorderColor = BorderGray,
            ),
        )
      }
    }
  }
}

@Composable
private fun SanxBottomPanel(
  isVipInjected: Boolean,
  isInjecting: Boolean,
  progress: Float,
  stageText: String,
  activeCount: Int,
  onInjectClick: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .background(PureBlack)
        .border(BorderStroke(1.dp, BorderGray), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    AnimatedVisibility(
      visible = isInjecting,
      enter = fadeIn(),
      exit = fadeOut(),
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardDark)
            .border(1.dp, BorderGray, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stageText,
            style = MaterialTheme.typography.labelMedium,
            color = PureWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "${(progress * 100f).roundToInt()}%",
            style = MaterialTheme.typography.labelMedium,
            color = PureWhite,
          )
        }

        LinearProgressIndicator(
          progress = { progress },
          color = PureWhite,
          trackColor = BorderGray,
          strokeCap = StrokeCap.Round,
          modifier =
            Modifier.fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp))
              .testTag("vip_injection_progress"),
        )
      }
    }

    Button(
      onClick = onInjectClick,
      enabled = !isInjecting,
      shape = RoundedCornerShape(10.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = PureWhite,
          contentColor = PureBlack,
          disabledContainerColor = CardActiveDark,
          disabledContentColor = MutedText,
        ),
      modifier =
        Modifier.fillMaxWidth()
          .height(54.dp)
          .testTag("inject_vip_button"),
    ) {
      Icon(
        imageVector = Icons.Filled.Bolt,
        contentDescription = null,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text =
          when {
            isInjecting -> "APLICANDO CÓDIGO VIP..."
            isVipInjected -> "INJETAR CÓDIGO VIP ($activeCount ATIVOS)"
            else -> "INJETAR CÓDIGO VIP"
          },
        style = MaterialTheme.typography.labelLarge,
      )
    }

    Text(
      text = "Desenvolvido por Raylan",
      style = MaterialTheme.typography.labelSmall,
      color = MutedText,
      textAlign = TextAlign.Center,
      modifier = Modifier.testTag("footer_credits"),
    )
  }
}

@Composable
private fun FeatureHelpModal(
  feature: VipFeature,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CardDark,
    titleContentColor = PureWhite,
    textContentColor = PureWhite,
    shape = RoundedCornerShape(14.dp),
    modifier = Modifier.border(1.dp, BorderGray, RoundedCornerShape(14.dp)),
    title = {
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = "MODO AVANÇADO",
          style = MaterialTheme.typography.labelSmall,
          color = MutedText,
        )
        Text(
          text = feature.name,
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
      }
    },
    text = {
      Text(
        text = feature.gamerExplanation,
        style = MaterialTheme.typography.bodyMedium,
        color = PureWhite,
      )
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = PureWhite, contentColor = PureBlack),
        modifier =
          Modifier.fillMaxWidth()
            .height(48.dp)
            .testTag("help_modal_close_button"),
      ) {
        Text(
          text = "ENTENDI",
          style = MaterialTheme.typography.labelLarge,
        )
      }
    },
  )
}
