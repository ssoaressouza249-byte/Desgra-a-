package com.raylan.sanxvip;

interface ISanxShizukuService {
    void destroy() = 16777114;
    int executeCommand(String command) = 1;
    int executeBatch(in String[] commands) = 2;
}
