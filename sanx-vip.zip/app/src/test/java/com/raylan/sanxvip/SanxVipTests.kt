package com.raylan.sanxvip

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.sanxvip.data.VipFeaturesCatalog
import com.raylan.sanxvip.model.VipTab
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SanxVipTests {

  @Test
  fun appIntegrityMatchesPackageAndName() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("com.raylan.sanxvip", context.packageName)
    assertEquals("Sanx Vip", context.getString(R.string.app_name))
    assertTrue(SecurityGuard.isAppIntact(context))
  }

  @Test
  fun catalogContainsExact35FeaturesSplit18And17() {
    assertEquals(35, VipFeaturesCatalog.allFeatures.size)
    assertEquals(18, VipFeaturesCatalog.featuresForTab(VipTab.MIRA_AVANCADA).size)
    assertEquals(17, VipFeaturesCatalog.featuresForTab(VipTab.PING_AVANCADO).size)
  }
}
